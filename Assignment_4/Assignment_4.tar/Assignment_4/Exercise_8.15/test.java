public class test extends Date{
	public static void main(String[] args){
		Date day1 = new Date(1, 2, 2003);
		Date day2 = new Date("April", 10, 2010);
		Date day3 = new Date(183, 2018);

		System.out.println(day1.toString1());
		System.out.println(day1.toString2());
		System.out.println(day1.toString3());
		System.out.println();
		
		System.out.println(day2.toString1());
		System.out.println(day2.toString2());
		System.out.println(day2.toString3());
		System.out.println();
		
		System.out.println(day3.toString1());
		System.out.println(day3.toString2());
		System.out.println(day3.toString3());
		System.out.println();





	}
}
