public class HourlyEmployeeTest{
	public static void main(String[] args){
		HourlyEmployee employee = new HourlyEmployee("Greg", "Yentz", "123-45-6789", 40.0, 10.0);
		System.out.println(employee.toString());
	
	
	
	
	}
}