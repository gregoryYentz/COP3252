#!/bin/bash
java enhanced 3.2 4.1 5.2 6 3.6
java enhanced 3.2 4.1 5.2 7 3.6
